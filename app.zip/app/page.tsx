import IntroSection from "./components/IntroSection";
import ResultSection from "./components/ResultSection";
import WaitingSection from "./components/WaitingSection";

export default function Home() {
  return (
    <div className="mx-auto w-[375px] min-w-[375px] max-w-[375px] bg-[#f3f2ef]">
      <IntroSection />
      <WaitingSection />
      <ResultSection />
    </div>
  );
}
